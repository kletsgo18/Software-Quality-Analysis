// Used with the Thermostat.java example, Chapter 8
public enum Period
{
   MORNING, DAY, EVENING, NIGHT
}
